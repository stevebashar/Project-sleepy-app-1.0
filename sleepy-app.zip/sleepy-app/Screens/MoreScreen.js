import * as React from 'react';
import { Image, Text, View, StyleSheet, TouchableOpacity} from 'react-native';
import Constants from 'expo-constants';

export default class MoreScreen extends React.Component{
}